﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DataAccessLayer.Models;
using APILogger.Logger;
using DataAccessLayer.Repository;

namespace MVCCore.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;

        private readonly ILogger _logger;

        public EmployeesController(IEmployeeRepository employeeRepository, ILogger logger)
        {
            _employeeRepository = employeeRepository;

            _logger = logger;
        }

        // GET: Employees
        public async Task<IActionResult> Index()
        {
            _logger.Information($"Service-Index-Executing started at {DateTime.UtcNow}");

            var employeeList = await _employeeRepository.GetAllEmployees(true);

            _logger.Information($"Service-Index-Executing ended at {DateTime.UtcNow}");

            return View(employeeList);
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            _logger.Information($"Service-Details-Executing started at {DateTime.UtcNow}");

            if (id == null)
            {
                return NotFound();
            }

            var employee = await _employeeRepository.GetEmployeeById(id.Value);

            if (employee == null)
            {
                return NotFound();
            }

            _logger.Information($"Service-Details-Executing ended at {DateTime.UtcNow}");

            return View(employee);
        }

        // GET: Employees/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EmployeeId,Name,City,Department,Gender")] Employee employee)
        {
            _logger.Information($"Service-Create-Executing started at {DateTime.UtcNow}");

            if (ModelState.IsValid)
            {
                employee.EmployeeId = Guid.NewGuid();

               await _employeeRepository.CreateEmployees(employee);

                return RedirectToAction(nameof(Index));
            }

            _logger.Information($"Service-Details-Executing ended at {DateTime.UtcNow}");

            return View(employee);
        }

        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            _logger.Information($"Service-Edit-Executing started at {DateTime.UtcNow}");

            if (id == null)
            {
                return NotFound();
            }

            var employee = await _employeeRepository.GetEmployeeById(id.Value);

            if (employee == null)
            {
                return NotFound();
            }

            _logger.Information($"Service-Edit-Executing started at {DateTime.UtcNow}");

            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("EmployeeId,Name,City,Department,Gender")] Employee employee)
        {
            _logger.Information($"Service-Edit-Executing started at {DateTime.UtcNow}");

            if (id != employee.EmployeeId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                   await _employeeRepository.UpdateEmployees(employee);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.EmployeeId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            _logger.Information($"Service-Edit-Executing ended at {DateTime.UtcNow}");

            return View(employee);
        }

        // GET: Employees/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            _logger.Information($"Service-Delete-Executing started at {DateTime.UtcNow}");

            if (id == null)
            {
                return NotFound();
            }

            var employee = await _employeeRepository.DeleteEmployeeById(id.Value);

            if (employee == 0)
            {
                return NotFound();
            }

            _logger.Information($"Service-Delete-Executing ended at {DateTime.UtcNow}");

            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            _logger.Information($"Service-DeleteConfirmed-Executing started at {DateTime.UtcNow}");

            var employee = await _employeeRepository.GetEmployeeById(id);

            await _employeeRepository.DeleteEmployeeById(employee.EmployeeId);

            _logger.Information($"Service-DeleteConfirmed-Executing ended at {DateTime.UtcNow}");

            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(Guid id)
        {
            return _employeeRepository.GetEmployeeById(id).Result.EmployeeId == id;
        }
    }
}
