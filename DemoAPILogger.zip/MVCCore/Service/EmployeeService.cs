﻿using APILogger.Logger;
using DataAccessLayer.Repository;
using MVCCore.Dto;
using MVCCore.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCore.Service
{
    public class EmployeeService : IEmployeeService
    {

        private readonly IEmployeeRepository _employeeRepository;
        private readonly ILogger _logger;

        public EmployeeService(ILogger logger, IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
            _logger = logger;
            CheckArguments();
        }

        private void CheckArguments()
        {
           // throw new NotImplementedException();
        }

        public Task<int> CreateEmployees(EmployeeViewModel employeeViewModel)
        {
            throw new NotImplementedException();
        }

        public Task<int> DeleteEmployeeById(Guid EmployeeId)
        {
            throw new NotImplementedException();
        }

        public async Task<List<EmployeeViewModel>> GetAllEmployees()
        {
            List<EmployeeViewModel> employeeResult = new List<EmployeeViewModel>();

            try
            {
                _logger.Information($"Service-GetAllEmployees-Executing started at {DateTime.UtcNow}");

                var employeeList = await _employeeRepository.GetAllEmployees(true).ConfigureAwait(false);

                employeeResult = Mapper.EmployeeMapper.MapEmployeeToEmployeeDto(employeeList);

                _logger.Information($"Service-GetAllEmployees-Executing completed at {DateTime.UtcNow}");
            }
            catch (Exception ex)
            {
                _logger.Error(ex.ToString());
            }

            return employeeResult;
        }

        public Task<int> UpdateEmployees(EmployeeViewModel employeeViewModel)
        {
            throw new NotImplementedException();
        }
    }
}
