﻿using APILogger.Logger;
using BusimessLogicLayer.ExceptionFilter;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MVCCore.IService;
using MVCCore.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCore
{
    public  static class RegisterServices
    {
        public static void RegisterConfigurationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped<ILogger, Logger>();

            services.AddScoped<IEmployeeRepository, EmployeeRepository>();

            services.AddScoped<IGlobalExceptionLogging, GlobalExceptionLogging>();
        }
    }
}
