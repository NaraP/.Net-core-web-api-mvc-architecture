﻿using DataAccessLayer.Models;
using MVCCore.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCore.Mapper
{
    public static class EmployeeMapper
    {
        public static List<EmployeeViewModel> MapEmployeeToEmployeeDto(IList<Employee> employeeList)
        {
            var employeesDtos = new List<EmployeeViewModel>();

            foreach (var emp in employeeList)
            {
                var empDto = new EmployeeViewModel();

                empDto.EmployeeId = emp.EmployeeId;
                empDto.Name = emp.Name;
                empDto.Department = emp.Department;
                empDto.Gender = emp.Gender;
                empDto.City = emp.City;

                employeesDtos.Add(empDto);
            }

            return employeesDtos;
        }
    }
}
