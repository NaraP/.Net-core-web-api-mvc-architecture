﻿using MVCCore.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCore.IService
{
   public interface IEmployeeService
    {
        Task<List<EmployeeViewModel>> GetAllEmployees();
        Task<int> CreateEmployees(EmployeeViewModel employeeViewModel);
        Task<int> UpdateEmployees(EmployeeViewModel employeeViewModel);
        Task<int> DeleteEmployeeById(Guid EmployeeId);
    }
}
