﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusimessLogicLayer.Helper
{
    public sealed class ResponseMessage : ResponseMessageBase
    {
        public ResponseMessage() : base()
        {
        }
        public ResponseMessage(int statusCode, string statusDescription, string errorMessage, object returnObj) : base(statusCode, statusDescription, errorMessage, returnObj)
        {
        }
    }
}
