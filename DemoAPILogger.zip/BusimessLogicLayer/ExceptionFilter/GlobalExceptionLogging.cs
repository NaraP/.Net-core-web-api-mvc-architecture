﻿using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusimessLogicLayer.ExceptionFilter
{
    public class GlobalExceptionLogging : IGlobalExceptionLogging
    {
        private readonly SampleDbContext _sampleDbContext;

        /// <summary>
        /// GlobalExceptionLogging
        /// </summary>
        /// <param name="abbRelCareContext"></param>
        /// <param name="logger"></param>
        public GlobalExceptionLogging(SampleDbContext sampleDbContext)
        {
            _sampleDbContext = sampleDbContext;
        }

        /// <summary>
        /// SaveGlobalExceptionLogging method is used for the global exception saved into the database
        /// </summary>
        /// <param name="exceptionLog"></param>
        public void SaveGlobalExceptionLogging(ExceptionLog exceptionLog)
        {
            _sampleDbContext.Add(exceptionLog);

            _sampleDbContext.SaveChanges();
        }
    }
}
