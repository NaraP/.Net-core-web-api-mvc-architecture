﻿using BusimessLogicLayer.Filters;
using DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Claims;
using System.Text;

namespace BusimessLogicLayer.ExceptionFilter
{
   public class GlobalException : IExceptionFilter
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IGlobalExceptionLogging _globalExceptionLogging;

        private readonly APILogger.Logger.ILogger  _logger;


        public GlobalException(IHttpContextAccessor httpContextAccessor, IGlobalExceptionLogging globalExceptionLogging, APILogger.Logger.ILogger logger)
        {
            _globalExceptionLogging = globalExceptionLogging;
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
        }

        public void OnException(ExceptionContext context)
        {
            HttpStatusCode status;

            String message = String.Empty;
            Guid UserId;
            string ApiActionName = string.Empty;
            string ApiControllerName = string.Empty;

            var exceptionType = context.Exception.GetType();
            if (exceptionType == typeof(UnauthorizedAccessException))
            {
                message = nameof(Constants.UnauthorizedAccess);
                status = HttpStatusCode.Unauthorized;
            }
            else if (exceptionType == typeof(NotImplementedException))
            {
                message = nameof(Constants.ServerError);
                status = HttpStatusCode.NotImplemented;
            }
            else if (exceptionType == typeof(MyAppException))
            {
                message = context.Exception.ToString();
                status = HttpStatusCode.InternalServerError;
            }
            else
            {
                message = context.Exception.Message;
                status = HttpStatusCode.NotFound;
            }
            context.ExceptionHandled = true;

            HttpResponse response = context.HttpContext.Response;
            response.StatusCode = (int)status;
            response.ContentType = nameof(Constants.JsonResponse);
            var error = message + " " + context.Exception.StackTrace;

            if (_httpContextAccessor.HttpContext.User != null && _httpContextAccessor.HttpContext.User.HasClaim(c => c.Type == ClaimTypes.UserData))
            {
                UserId = Guid.Parse(_httpContextAccessor.HttpContext.User.FindFirst(c => c.Type == ClaimTypes.UserData).Value);
            }

            string arrayRequestPath = _httpContextAccessor.HttpContext.Request.Path;

            string RemoteIpAddr = _httpContextAccessor.HttpContext.Connection.RemoteIpAddress.ToString();

            if (!string.IsNullOrEmpty(arrayRequestPath))
            {
                string[] ControllerActionName = arrayRequestPath.Split('/');
                ApiControllerName = ControllerActionName[2];
                ApiActionName = ControllerActionName[3];
            }
            var ExceptionTs = DateTime.Now.ToUniversalTime();

            var now = DateTime.Now.ToUniversalTime();

            ExceptionLog exceptionLog = new ExceptionLog
            {
                ExceptionId = Guid.NewGuid(),
                ExceptionMsg = error,
                ExceptionType = exceptionType.ToString(),
                ExceptionSource = context.Exception.Source,
                ExceptionUrl = _httpContextAccessor.HttpContext.Request.Path,
                ControllerName = ApiControllerName,
                ActionName = ApiActionName,
                ExceptionTs = ExceptionTs,
                CreateUser = UserId,
                CreateTs = now,
                RemoteIpAddr = RemoteIpAddr
            };

            //Logging the errors to file by using serilog
            _logger.Error(error);
    
            //Save error logs into database table
            _globalExceptionLogging.SaveGlobalExceptionLogging(exceptionLog);
        }
    }
}
