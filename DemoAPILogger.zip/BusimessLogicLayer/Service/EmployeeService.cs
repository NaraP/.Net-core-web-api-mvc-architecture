﻿using APILogger.Logger;
using BusimessLogicLayer.Dto;
using BusimessLogicLayer.Filters;
using BusimessLogicLayer.Helper;
using BusimessLogicLayer.IService;
using DataAccessLayer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using ILogger = APILogger.Logger.ILogger;

namespace BusimessLogicLayer.Service
{ 
  public  class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ILogger _logger;

        public EmployeeService(ILogger logger, IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
            _logger = logger;
            CheckArguments();
        }

        public async Task<ResponseMessage> CreateEmployees(EmployeeDto employeeDto)
        {
            ResponseMessage responseMessage = new ResponseMessage();

            _logger.Information($"Service-CreateEmployees-Executing started at {DateTime.UtcNow}");

            var employee = Mapper.EmployeeMapper.MapEmployeeDtoToEmployee(employeeDto);

            var result = await _employeeRepository.CreateEmployees(employee).ConfigureAwait(false);

            if (result != 0)
            {
                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.Created);
                responseMessage.ErrorMessage = " Employee created susccessfuly " + employeeDto.Name;
                responseMessage.returnObj = employee.Name;
            }
            else
            {
                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest);
                responseMessage.StatusDescription = "Employee creation failed";
                responseMessage.ErrorMessage = $"Employee Name {employeeDto.Name} creation failed";
            }

            _logger.Information($"Service-CreateEmployees-Executing completed at {DateTime.UtcNow}");

            return responseMessage;
        }

        public Task<ResponseMessage> DeleteEmployeeById(Guid EmployeeId)
        {
            throw new NotImplementedException();
        }

        public async Task<ResponseMessage> GetAllEmployees()
        {
            ResponseMessage responseMessage = new ResponseMessage();

            try
            {
                _logger.Information($"Service-GetAllEmployees-Executing started at {DateTime.UtcNow}");

                var employeeList = await _employeeRepository.GetAllEmployees(true).ConfigureAwait(false);

                if (employeeList.Any() || employeeList.Any())
                {
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                    responseMessage.returnObj = Mapper.EmployeeMapper.MapEmployeeToEmployeeDto(employeeList);
                }
                else
                {
                    _logger.Information("No employees found");
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.NotFound);
                }

                _logger.Information($"Service-GetAllEmployees-Executing completed at {DateTime.UtcNow}");

            }
            catch (Exception ex)
            {
                _logger.Error(ex.ToString());
            }
            return responseMessage;
        }

        public Task<ResponseMessage> UpdateEmployees(EmployeeDto employeeDto)
        {
            throw new NotImplementedException();
        }

        public void CheckArguments()
        {
            _employeeRepository.CheckArgumentIsNull(nameof(_employeeRepository));
            _logger.CheckArgumentIsNull(nameof(_logger));
        }
    }
}
