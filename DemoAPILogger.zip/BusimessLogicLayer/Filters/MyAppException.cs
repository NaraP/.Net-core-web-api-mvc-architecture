﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusimessLogicLayer.Filters
{
    public class MyAppException : Exception
    {
        public MyAppException()
        { }

        public MyAppException(string message)
            : base(message)
        { }

        public MyAppException(string message, Exception innerException)
            : base(message, innerException)
        { }
    }

}
