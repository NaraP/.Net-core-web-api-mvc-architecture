﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusimessLogicLayer.Filters
{
  public static  class Constants
    {
        public const string JsonResponse = "application/json";
        public const string UnauthorizedAccess = "Unauthorized Access";
        public const string ServerError = "A server error occurred.";
    }
}
