﻿using BusimessLogicLayer.Dto;
using BusimessLogicLayer.Helper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BusimessLogicLayer.IService
{
    public interface IEmployeeService
    {
        Task<ResponseMessage> GetAllEmployees();
        Task<ResponseMessage> CreateEmployees(EmployeeDto employeeDto);
        Task<ResponseMessage> UpdateEmployees(EmployeeDto employeeDto);
        Task<ResponseMessage> DeleteEmployeeById(Guid EmployeeId);
    }
}
