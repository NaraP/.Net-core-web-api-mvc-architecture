﻿using BusimessLogicLayer.Dto;
using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusimessLogicLayer.Mapper
{
    public static class EmployeeMapper
    {
        public static IList<EmployeeDto> MapEmployeeToEmployeeDto(IList<Employee> employeeList)
        {
            var employeesDtos = new List<EmployeeDto>();

            foreach (var emp in employeeList)
            {
                var empDto = new EmployeeDto();

                empDto.EmployeeId = emp.EmployeeId;
                empDto.Name = emp.Name;
                empDto.Department = emp.Department;
                empDto.Gender = emp.Gender;
                empDto.City = emp.City;

                employeesDtos.Add(empDto);
            }

            return employeesDtos;
        }

        public static Employee MapEmployeeDtoToEmployee(EmployeeDto employeeDto)
        {
            var newEmployee = new Employee();

            newEmployee.EmployeeId = Guid.NewGuid();
            newEmployee.Name = employeeDto.Name;
            newEmployee.Department = employeeDto.Department;
            newEmployee.Gender = employeeDto.Gender;
            newEmployee.City = employeeDto.City;

            return newEmployee;
        }
    }
}
