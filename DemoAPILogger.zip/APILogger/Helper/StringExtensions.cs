﻿using Serilog.Parsing;
using System;
using System.Collections.Generic;
using System.Text;

namespace APILogger.Helper
{
    public static class StringExtensions
    {
        public static string SerilogMessageToMessage(this string input)
        {
            var parser = new MessageTemplateParser();
            var template = parser.Parse(input);
            var format = new StringBuilder();
            var index = 0;
            foreach (var tok in template.Tokens)
            {
                if (tok is TextToken)
                    format.Append(tok);
                else
                    format.Append("{" + index++ + "}");
            }
            return format.ToString();
        }
    }
}
