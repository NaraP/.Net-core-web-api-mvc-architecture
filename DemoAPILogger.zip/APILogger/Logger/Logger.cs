﻿using APILogger.Helper;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Events;
using Serilog.Exceptions;
using Serilog.Sinks.Elasticsearch;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace APILogger.Logger
{
    public class Logger : ILogger
    {
        private readonly Serilog.ILogger _seriLogger;

        public Logger()
        {
            var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json")
            .AddEnvironmentVariables()
            .Build();

            _seriLogger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .CreateLogger();
        }

        public void Debug(string messageTemplate)
            => _seriLogger.Debug(messageTemplate);

        public void Debug(string messageTemplate, params object[] propertyValues)
            => _seriLogger.Debug(messageTemplate, propertyValues);

        public void Debug(Exception exception, string messageTemplate)
            => _seriLogger.Debug(exception, messageTemplate);

        public void Debug(Exception exception, string messageTemplate, params object[] propertyValues)
            => _seriLogger.Debug(exception, messageTemplate, propertyValues);

        public void Information(string messageTemplate)
            => _seriLogger.Information(messageTemplate);

        public void Information(string messageTemplate, params object[] propertyValues)
            => _seriLogger.Information(messageTemplate, propertyValues);

        public void Information(Exception exception, string messageTemplate)
            => _seriLogger.Information(exception, messageTemplate);

        public void Information(Exception exception, string messageTemplate, params object[] propertyValues)
            => _seriLogger.Information(exception, messageTemplate, propertyValues);

        public void Warning(string messageTemplate)
            => _seriLogger.Warning(messageTemplate);

        public void Warning(string messageTemplate, params object[] propertyValues)
            => _seriLogger.Warning(messageTemplate, propertyValues);

        public void Warning(Exception exception, string messageTemplate)
            => _seriLogger.Warning(exception, messageTemplate);

        public void Warning(Exception exception, string messageTemplate, params object[] propertyValues)
            => _seriLogger.Warning(exception, messageTemplate, propertyValues);

        public void Error(string messageTemplate)
        {
            _seriLogger.Error(messageTemplate);
            SendErrorToApi(messageTemplate);
        }

        public void Error(string messageTemplate, params object[] propertyValues)
        {
            _seriLogger.Error(messageTemplate, propertyValues);
            SendErrorToApi(messageTemplate, propertyValues);
        }

        public void Error(Exception exception, string messageTemplate)
        {
            _seriLogger.Error(exception, messageTemplate);
            HandleExternalException(exception);
        }

        public void Error(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            _seriLogger.Error(exception, messageTemplate, propertyValues);
            HandleExternalException(exception);
        }

        public void Fatal(string messageTemplate)
        {
            _seriLogger.Fatal(messageTemplate);
            SendErrorToApi(messageTemplate);
        }

        public void Fatal(string messageTemplate, params object[] propertyValues)
        {
            _seriLogger.Fatal(messageTemplate, propertyValues);
            SendErrorToApi(messageTemplate, propertyValues);
        }

        public void Fatal(Exception exception, string messageTemplate)
        {
            _seriLogger.Fatal(exception, messageTemplate);
            HandleExternalException(exception);
        }

        public void Fatal(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            _seriLogger.Fatal(exception, messageTemplate, propertyValues);
            HandleExternalException(exception);
        }


        private void SendErrorToApi(string messageTemplate, params object[] propertyValues)
        {
            SendErrorToApi(string.Format(messageTemplate.SerilogMessageToMessage(), propertyValues));
        }

        private void SendErrorToApi(string messageTemplate)
        {
            HandleExternalException(new Exception(messageTemplate));
        }

        private void HandleExternalException(Exception exception)
        {
            try
            {
               ///
            }
            catch (Exception ex)
            {
                _seriLogger.Error(ex, "Cannot notify external error logging service");
            }
        }
    }
}
