﻿using APILogger.Logger;
using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace MVC.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;

        private readonly ILogger _logger;

        public EmployeesController(IEmployeeRepository employeeRepository, ILogger logger)
        {
            _employeeRepository = employeeRepository;

            _logger = logger;
        }

        // GET: Employees
        public async Task<ActionResult> Index()
        {
            _logger.Information($"Service-Index-Executing started at {DateTime.UtcNow}");

            var employeeList = await _employeeRepository.GetAllEmployees(true);

            _logger.Information($"Service-Index-Executing ended at {DateTime.UtcNow}");

            return View(employeeList);
        }

        // GET: Employees/Details/5
        public async Task<ActionResult> Details(Guid? id)
        {
            _logger.Information($"Service-Details-Executing started at {DateTime.UtcNow}");

            var employee = await _employeeRepository.GetEmployeeById(id.Value);

            _logger.Information($"Service-Details-Executing ended at {DateTime.UtcNow}");

            return View(employee);
        }

        // GET: Employees/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Employee employee)
        {
            _logger.Information($"Service-Create-Executing started at {DateTime.UtcNow}");

            if (ModelState.IsValid)
            {
                employee.EmployeeId = Guid.NewGuid();

                await _employeeRepository.CreateEmployees(employee);

                return RedirectToAction(nameof(Index));
            }

            _logger.Information($"Service-Details-Executing ended at {DateTime.UtcNow}");

            return View(employee);
        }

        // GET: Employees/Edit/5
        public async Task<ActionResult> Edit(Guid? id)
        {
            _logger.Information($"Service-Edit-Executing started at {DateTime.UtcNow}");

            var employee = await _employeeRepository.GetEmployeeById(id.Value);

            _logger.Information($"Service-Edit-Executing started at {DateTime.UtcNow}");

            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(Guid id, Employee employee)
        {
            _logger.Information($"Service-Edit-Executing started at {DateTime.UtcNow}");

            if (ModelState.IsValid)
            {
                try
                {
                    await _employeeRepository.UpdateEmployees(employee);
                }
                catch (DbUpdateConcurrencyException)
                {
                }
                return RedirectToAction(nameof(Index));
            }

            _logger.Information($"Service-Edit-Executing ended at {DateTime.UtcNow}");

            return View(employee);
        }

        // GET: Employees/Delete/5
        public async Task<ActionResult> Delete(Guid? id)
        {
            _logger.Information($"Service-Delete-Executing started at {DateTime.UtcNow}");

            var employee = await _employeeRepository.DeleteEmployeeById(id.Value);

            _logger.Information($"Service-Delete-Executing ended at {DateTime.UtcNow}");

            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(Guid id)
        {
            _logger.Information($"Service-DeleteConfirmed-Executing started at {DateTime.UtcNow}");

            var employee = await _employeeRepository.GetEmployeeById(id);

            await _employeeRepository.DeleteEmployeeById(employee.EmployeeId);

            _logger.Information($"Service-DeleteConfirmed-Executing ended at {DateTime.UtcNow}");

            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(Guid id)
        {
            return _employeeRepository.GetEmployeeById(id).Result.EmployeeId == id;
        }
    }
}
