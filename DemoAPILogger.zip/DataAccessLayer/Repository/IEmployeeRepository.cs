﻿using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repository
{
   public interface IEmployeeRepository
    {
        Task<Employee> GetEmployeeById(Guid employeeId);
        Task<Employee> GetEmployeeByName(string name, Guid employeeId);
        Task<IList<Employee>> GetAllEmployees(bool includeDetails);
        Task<int> CreateEmployees(Employee employee);
        Task<int> UpdateEmployees(Employee employee);
        Task<int> DeleteEmployeeById(Guid employeeId);
    }
}
