﻿using DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly SampleDbContext _sampleDbContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public EmployeeRepository(SampleDbContext sampleDbContext, IHttpContextAccessor httpContextAccessor)
        {
            _sampleDbContext = sampleDbContext;
            _httpContextAccessor = httpContextAccessor;
        }
        public async Task<int> CreateEmployees(Employee employee)
        {
            AddAuditTrial(employee, true);

            await _sampleDbContext.Employee.AddAsync(employee).ConfigureAwait(false);

            return await _sampleDbContext.SaveChangesAsync().ConfigureAwait(false);
        }

        private void AddAuditTrial(Employee employee, bool createOperation)
        {
            Guid userId = Guid.Parse("d0f261db-12da-44d1-a01a-5eeb543b8343");

            if (createOperation)
            {
                employee.CreateTs = DateTime.UtcNow;
                employee.CreateUser = userId;
            }
            else
            {
                employee.UpdateTs = DateTime.UtcNow;
                employee.UpdateUser = userId;
            }
        }

        public async Task<int> DeleteEmployeeById(Guid employeeId)
        {
            var employee = await _sampleDbContext.Employee.Where(s => employeeId.Equals(employeeId)).FirstOrDefaultAsync().ConfigureAwait(false);
           
            _sampleDbContext.Employee.UpdateRange(employee);

            return await _sampleDbContext.SaveChangesAsync().ConfigureAwait(false);
        }

        public async Task<IList<Employee>> GetAllEmployees(bool includeDetails)
        {
            var employees = await _sampleDbContext.Employee.ToListAsync().ConfigureAwait(false);

            return employees;
        }
         
        public async Task<Employee> GetEmployeeById(Guid employeeId)
        {
            var employee = await _sampleDbContext.Employee.SingleOrDefaultAsync(s => s.EmployeeId.Equals(employeeId));
            return employee;
        }

        public async Task<Employee> GetEmployeeByName(string name, Guid employeeId)
        {
            var Employee = await _sampleDbContext.Employee.
                                          SingleOrDefaultAsync(s => (s.Name.Trim().ToLower().Equals(name.Trim().ToLower()) && s.EmployeeId.Equals(employeeId))).ConfigureAwait(false);
            return Employee;
        }

        public async Task<int> UpdateEmployees(Employee employee)
        {
            AddAuditTrial(employee,true);

            _sampleDbContext.Employee.Update(employee);

            return await _sampleDbContext.SaveChangesAsync().ConfigureAwait(false);
        }
    }
}

