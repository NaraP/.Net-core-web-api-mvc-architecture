﻿using APILogger.Logger;
using BusimessLogicLayer.IService;
using BusimessLogicLayer.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusimessLogicLayer.ExceptionFilter;
using DataAccessLayer.Repository;

namespace DemoAPILogger
{
    public static class RegisterServices
    {

        public static void RegisterConfigurationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped<ILogger, Logger>();

            services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            services.AddScoped<IEmployeeService, EmployeeService>();

            services.AddScoped<IGlobalExceptionLogging, GlobalExceptionLogging>();

        }
    }
}
