﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusimessLogicLayer.IService;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BusimessLogicLayer;
using System.Net;
using Microsoft.Extensions.Logging;
using DemoAPILogger.APIHelper;
using BusimessLogicLayer.Dto;

namespace DemoAPILogger.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly ILogger<EmployeeController> _employeeLogger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IEmployeeService _employeeService;
        private readonly IHostingEnvironment _env;

        public EmployeeController(IHostingEnvironment env, IEmployeeService employeeService, ILogger<EmployeeController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _employeeLogger = logger;
            _httpContextAccessor = httpContextAccessor;
            _employeeService = employeeService;
            _env = env;
           CheckArguments();
        }

        [HttpGet("GetAllEmployees", Name = nameof(GetAllEmployees))]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<ActionResult> GetAllEmployees()
        {
            try
            {
                using(_employeeLogger.BeginScope($"API-GetAllEmployees-Initiated at{DateTime.UtcNow}"))
                {
                   _employeeLogger.LogInformation("API-GetAllEmployees-Getting list of skills");

                    var result = await _employeeService.GetAllEmployees().ConfigureAwait(false);

                    if (result.StatusCode == Convert.ToInt32(HttpStatusCode.OK))
                    {

                        _employeeLogger.LogInformation(LoggingEvents.ListItems, "API-GetAllEmployees");
                        return StatusCode(result.StatusCode, result.returnObj);
                    }
                    else
                    {
                        _employeeLogger.LogInformation(LoggingEvents.GetItemNotFound, "API-GetAllEmployees");
                        return StatusCode(result.StatusCode);
                    }
                }
            }
            catch (Exception ex)
            {
                _employeeLogger.LogError
                   (ex,
                    $"API-GetAllEmployees-Exception {DateTime.UtcNow}"
                  );

                return StatusCode((int)HttpStatusCode.BadRequest,
                     (_env.IsDevelopment()) ? ex.ToString() : "An error occured while processing GetAllEmployees");
            }
        }

        [HttpPost("CreateEmployee", Name = nameof(CreateEmployee))]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        public async Task<ActionResult> CreateEmployee([FromBody] EmployeeDto employeeDto)
        {
            try
            {
                using (_employeeLogger.BeginScope($"API-CreateEmployee-Initiated at {DateTime.UtcNow}"))
                {
                    var result = await _employeeService.CreateEmployees(employeeDto).ConfigureAwait(false);

                    if (result.StatusCode == Convert.ToInt32(HttpStatusCode.Created))
                    {
                        _employeeLogger.LogInformation($"API-CreateEmployee-Completed at {DateTime.UtcNow}");
                    }
                    else
                    {
                        _employeeLogger.LogInformation($"API-CreateEmployee-Not Completed at {DateTime.UtcNow}");
                    }

                    return StatusCode(result.StatusCode, result);
                }
            }
            catch (Exception ex)
            {
                _employeeLogger.LogError
                   (ex,
                    $"API-CreateEmployee-Exception {DateTime.UtcNow}"
                  );

                return StatusCode((int)HttpStatusCode.BadRequest,
                    (_env.IsDevelopment()) ? ex.ToString() : "An error occured while processing CreateEmployee");
            }
        }

        private void CheckArguments()
        {
            _employeeService.CheckArgumentIsNull(nameof(_employeeLogger));
            _employeeService.CheckArgumentIsNull(nameof(_employeeService));
            _httpContextAccessor.CheckArgumentIsNull(nameof(_httpContextAccessor));
           _env.CheckArgumentIsNull(nameof(_env));
        }
    }
}