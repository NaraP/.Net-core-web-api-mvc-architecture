using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusimessLogicLayer.ExceptionFilter;
using BusimessLogicLayer.Filters;
using DataAccessLayer.Models;
using DemoAPILogger;
using DemoAPILogger.Swagger;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;

namespace BusimessLogicLayer
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var connectionString = Configuration.GetConnectionString("PostGreSqlConnection");

            services.AddDbContext<SampleDbContext>(options => options.UseNpgsql(connectionString), ServiceLifetime.Scoped);

            //Registering the all services 
            services.RegisterConfigurationServices(Configuration);

            //Registering the CORS
            services.RegisterChainOfConfigServices(Configuration);

            services.AddMvc(config =>
            {
                config.Filters.Add(typeof(GlobalException));
                config.Filters.Add(typeof(ValidateModelAttribute));
            });

            services.AddControllers();

            services.AddSwaggerConfigurationSetting(Configuration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            //Add logs to serilog
            loggerFactory.AddSerilog();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();

            //app.UseCors("CorsPolicy");
            app.UseSwaggerMiddleWare();

            //app.UseCors(builder => builder.AllowAnyOrigin()
            //                    .AllowAnyMethod()
            //                    .AllowAnyHeader());

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
