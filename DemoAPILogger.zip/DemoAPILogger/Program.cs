using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;

namespace BusimessLogicLayer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateFileLogger();

            CreateHostBuilder(args).Build().Run();
        }

		private static void CreateFileLogger()
		{
			Log.Logger = new LoggerConfiguration()
							   .MinimumLevel.Information()
							   .MinimumLevel.Override("DemoAPILogger", LogEventLevel.Warning)
								   .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
									   .MinimumLevel.Override("System", LogEventLevel.Error)
							   .WriteTo.File("Logs/Apilogger.txt",
									   //  LogEventLevel.Information, // Minimum Log level
									   rollingInterval: RollingInterval.Day, // This will append time period to the filename like Example20180316.txt
																			 // retainedFileCountLimit: null,
																			 // fileSizeLimitBytes: null,
									   outputTemplate: "{Timestamp:dd-MMM-yyyy HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj}{NewLine}{Exception}", // Set custom file format
									  shared: true // Shared between multi-process shared log files
									   )
							   .CreateLogger();
		}

		public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
